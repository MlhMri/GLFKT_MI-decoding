function W = fkt(data1, data2, m)

% This function computes the projection matrix obtained using
% Fukunaga-Koontz Transform as illustrated in:
% M. Miri, et al. "Spectral representation of EEG data using learned graphs
% with application to motor imagery decoding." Biomedical Signal Processing
% and Control 87 (2024): 105537.

%--Inputs:
% data1: data of class1 (time samples x channels x trials)
% data2: data of class2 (time samples x channels x trials)
% m: number of output filters
%--Output:
% W: projection matrix


% Maliheh Miri, December 2024.
%=========================================================================%

if nargin == 2
    m = 1;
end


% 1. Covariance matrices of two classes:
sigma1 = 0;
sigma2 = 0;

N1 = size(data1,3);
N2 = size(data2,3);
mx = max([N1,N2]);

for i = 1:mx
    if i <= N1
        f1 = data1(:,:,i)';
        f1 = f1 - repmat(mean(f1,2),1,size(f1,2));
        c1 = (f1*f1')/trace(f1*f1');
        sigma1 = sigma1 + c1;
    end
    if i <= N2
        f2 = data2(:,:,i)';
        f2 = f2 - repmat(mean(f2,2),1,size(f2,2));
        c2 = (f2*f2')/trace(f2*f2');
        sigma2 = sigma2 + c2;
    end
end

Sigma_1 = sigma1 / size(data1,3);
Sigma_2 = sigma2 / size(data2,3);
Sigma = Sigma_1 + Sigma_2;

% 2. Eigen decomposition of covariance matrix:
[V,Gamma] = eig(Sigma);
[Gamma,ind] = sort(diag(Gamma),'descend');
V = V(:,ind);

% 3. Whitening transform:
P = sqrt(inv(diag(Gamma))) * V';

% 4. Simultaneous diagonalization:
S1 = P * Sigma_1 * P';
S2 = P * Sigma_2 * P';

[B,Gamma_1] = eig(S1);

[Gamma_1,ind] = sort(diag(Gamma_1),'descend');
B = B(:,ind);

% 5. Projection matrix:
W = B'*P;
W = W([1:m,end-m+1:end],:);

end

