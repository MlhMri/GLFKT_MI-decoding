function data_norm = demean_norm (data, U)

% This function computes the de-meaned and normalized graph signals as
% illustrated in:
% M. Miri, et al. "Spectral representation of EEG data using learned graphs
% with application to motor imagery decoding." Biomedical Signal Processing
% and Control 87 (2024): 105537.

%--Inputs:
% data: graph signals (time samples x channels x trials)
% U: full set of the graph's eigenvectors corresponding to the eigenvalues,
% sorted in ascending order.
%--Output:
% data_norm: de-meaned and normalized graph signals


% Maliheh Miri, December 2024.
%=========================================================================%

data_norm = [];

for k = 1:size(data,3)
    f1 = data(:,:,k)';

    for k2 = 1:size(f1,2)
        f1_demean = f1(:,k2) - (U(:,1)' * f1(:,k2) * U(:,1));
        f1_tild_t = f1_demean / norm(f1_demean);
        f1_tild(:,k2) = f1_tild_t;
    end

    data_norm(:,:,k) = f1_tild;

    f1_tild_hat = U(:,1)' * f1_tild;
    assert(all(f1_tild_hat(1,:)<1e-9),'signals not demeaned!');
end

end